// অ্যাডমিন: "👤 User Info" ট্যাব + ড্যাশবোর্ডে অনলাইন বক্স (Online Count, Visitor List, Join/Leave, Last Active)।
// নাম ক্লিক (data-uu="ডিভাইস আইডি") করলে যেকোনো ট্যাব থেকে পুরো User Info খোলে। admin-anonchat.js-এর পরে ও admin.js-এর আগে লোড হয়। SQL: supabase-userinfo.sql
(function () {
  var M = function () { return window.MCA; }, ST = { q: "", on: false, off: 0, st: "0", g: "", d: "", s: "", c: "", dv: "", os: "", br: "", ph: "", sc: "", ac: "", so: "new", f: "", t: "", open: "" }, PREV = null, MISS = {}, FEED = [], LAST = null, ERR = "", tick = null;
  var SK = "mcUnF";
  try { var sv = JSON.parse(localStorage.getItem(SK) || "null"); if (sv) Object.keys(sv).forEach(function (k) { if (k in ST) ST[k] = sv[k]; }); } catch (e) {}
  function saveST() { try { localStorage.setItem(SK, JSON.stringify(ST)); } catch (e) {} }
  var esc = function (t) { return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var bd = function (s) { return String(s).replace(/\d/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); };
  function ago(t) { if (!t) return "জানা নেই"; var s = Math.max(0, Math.round((Date.now() - t) / 1000)); if (s < 60) return "এইমাত্র"; var m = Math.round(s / 60); if (m < 60) return bd(m) + " মিনিট আগে"; var h = Math.round(m / 60); if (h < 24) return bd(h) + " ঘণ্টা আগে"; return bd(Math.round(h / 24)) + " দিন আগে"; }
  function dur(a) { if (!a) return ""; var m = Math.max(1, Math.round((Date.now() - new Date(a).getTime()) / 60000)); return m < 60 ? bd(m) + " মিনিট" : bd(Math.floor(m / 60)) + " ঘণ্টা " + bd(m % 60) + " মিনিট"; }
  function ua(u, i) { // সরল ব্রাউজার/ডিভাইস শনাক্তকরণ (আনুমানিক)
    u = String(u || ""); if (!u) return "পাওয়া যায়নি";
    var b = /FBAN|FBAV|FB_IAB/.test(u) ? "Facebook অ্যাপের ব্রাউজার" : /Messenger/.test(u) ? "Messenger ব্রাউজার" : /Instagram/.test(u) ? "Instagram ব্রাউজার" : /SamsungBrowser\/([\d.]+)/.test(u) ? "Samsung Internet " + RegExp.$1.split(".")[0] : /EdgA?\/([\d.]+)/.test(u) ? "Edge " + RegExp.$1.split(".")[0] : /OPR\/([\d.]+)/.test(u) ? "Opera " + RegExp.$1.split(".")[0] : /Firefox\/([\d.]+)/.test(u) ? "Firefox " + RegExp.$1.split(".")[0] : /Chrome\/([\d.]+)/.test(u) ? "Chrome " + RegExp.$1.split(".")[0] : /Version\/([\d.]+).*Safari/.test(u) ? "Safari " + RegExp.$1.split(".")[0] : "অজানা ব্রাউজার";
    var o = /Android ([\d.]+)/.test(u) ? "Android " + RegExp.$1 : /iPhone OS ([\d_]+)/.test(u) ? "iOS " + RegExp.$1.replace(/_/g, ".") : /iPad/.test(u) ? "iPadOS" : /Windows NT ([\d.]+)/.test(u) ? "Windows" : /Mac OS X/.test(u) ? "macOS" : /Linux/.test(u) ? "Linux" : "";
    var mo = i && i.model ? String(i.model) : /Android [\d.]+; ([^;)]+)/.test(u) ? RegExp.$1.replace(/ Build.*/, "").trim() : /iPhone/.test(u) ? "iPhone" : "";
    var t = /iPad|Tablet/.test(u) ? "ট্যাবলেট" : /Mobi|Android|iPhone/.test(u) ? "মোবাইল" : "কম্পিউটার";
    return [b, o, mo && mo !== "K" ? mo : "", t].filter(Boolean).join(" · ");
  }
  function brand(m) { // মডেল কোড থেকে আনুমানিক ব্র্যান্ড
    var t = String(m || ""); return /^SM-|^GT-|^SC-/i.test(t) ? "Samsung" : /^RMX|realme/i.test(t) ? "Realme" : /^CPH|oppo/i.test(t) ? "OPPO" : /^V\d{4}|vivo/i.test(t) ? "vivo" : /^(Redmi|M\d{4}|2\d{7}|2\d{3}\w{2,})/i.test(t) ? "Xiaomi/Redmi/Poco (আনুমানিক)" : /^itel/i.test(t) ? "itel" : /^TECNO|^T[A-Z]?\d/i.test(t) ? "Tecno (আনুমানিক)" : /^Infinix|^X\d{3,4}/i.test(t) ? "Infinix (আনুমানিক)" : /^Pixel/i.test(t) ? "Google Pixel" : /^(ONEPLUS|[A-Z]{2}\d{4}$)/i.test(t) ? "OnePlus (আনুমানিক)" : /^moto|^XT\d/i.test(t) ? "Motorola" : /^iPhone/i.test(t) ? "Apple" : "";
  }
  function phoneModel(u, i) { // ফোন মডেল: সাইট নিজে ডিভাইস থেকে মডেল পাঠায় (Chrome); না এলে UA থেকে
    u = String(u || ""); var m = i && i.model ? String(i.model) : /Android [\d.]+; ([^;)]+)/.test(u) ? RegExp.$1.replace(/ Build.*/, "").trim() : /iPhone/.test(u) ? "iPhone (মডেল আইফোন লুকিয়ে রাখে)" : /iPad/.test(u) ? "iPad" : "";
    if (!m || m === "K") return /Mobi|Android/.test(u) ? "পাওয়া যায়নি (ইউজার নতুন করে সাইট খুললে আসবে; Firefox/Safari মডেল দেয় না)" : /Windows|Macintosh|Linux/.test(u) ? "কম্পিউটার" : "";
    var b = brand(m); return m + (b ? " · " + b : "");
  }
  function loc(x) { var p = [x.city, x.region, x.country].filter(function (v) { return v && v !== "XX" && v !== "T1"; }); return p.length ? p.join(", ") + " (আনুমানিক)" : "পাওয়া যায়নি"; }
  function nm(x) { return x.gname || x.nick || "অজানা"; }

  var st = document.createElement("style");
  st.textContent = "#view label[hidden]{display:none!important}button.lk{background:none;color:var(--g);padding:0;border:0;text-decoration:underline;font-weight:700;cursor:pointer;font-size:inherit}.udot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#9aa3a0;margin-right:5px}.udot.on{background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.25)}" +
    ".unmo{position:fixed;inset:0;background:rgba(0,0,0,.55);display:grid;place-items:center;z-index:100;padding:12px}.unb{background:var(--card);color:var(--fg);border-radius:14px;padding:14px;width:min(520px,100%);max-height:92vh;overflow:auto;display:grid;gap:8px}" +
    ".unb dl{display:grid;grid-template-columns:auto 1fr;gap:5px 12px;margin:0;font-size:14px}.unb dt{color:var(--mut);font-weight:600}.unb dd{margin:0;overflow-wrap:anywhere}.unb h3{margin:6px 0 0;font-size:15px}" +
    "#unT{position:fixed;top:10px;right:10px;display:grid;gap:6px;z-index:101;max-width:min(320px,calc(100vw - 20px))}#unT div{background:#10261b;color:#fff;border-radius:10px;padding:8px 12px;font-size:14px;box-shadow:0 4px 14px rgba(0,0,0,.3)}#unT div.l{background:#4a4f4c}" +
    ".onb h2 small{font-size:13px;color:var(--mut);font-weight:500;margin-left:6px}.onf{font-size:13px;display:grid;gap:2px;margin-top:6px}.memWrap{border:1px solid #e0e6dc;border-radius:10px;padding:8px 10px;margin:6px 0}.memHead{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:baseline}.memBar{display:flex;height:16px;border-radius:8px;overflow:hidden;background:#e5e7eb;margin:6px 0;position:relative}.memBar span{display:block;height:100%}.memPulse{position:absolute;inset:0;background:linear-gradient(90deg,#e5e7eb,#cbd5e1,#e5e7eb);animation:memP 1.2s linear infinite;background-size:200% 100%}@keyframes memP{from{background-position:200% 0}to{background-position:-200% 0}}.memLegend{display:grid;gap:4px;font-size:13px}.memRow{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.memDot{width:10px;height:10px;border-radius:3px;display:inline-block}";
  document.head.appendChild(st);
  function toastBox() { var t = document.getElementById("unT"); if (!t) { t = document.createElement("div"); t.id = "unT"; document.body.appendChild(t); } return t; }
  function notify(kind, r) { var d = document.createElement("div"); d.className = kind === "leave" ? "l" : ""; d.textContent = (kind === "leave" ? "⚪ চলে গেছে: " : "🟢 জয়েন করেছে: ") + r.n + (r.d ? " (" + r.d + ")" : ""); toastBox().appendChild(d); setTimeout(function () { d.remove(); }, 7000); }

  // ---------- অনলাইন পোলিং (প্রতি ৮ সেকেন্ডে) ----------
  function poll() {
    var app = document.getElementById("app"); if (!M() || !app || app.hidden) return;
    M().rpc("mc2_admin_online").then(function (d) {
      ERR = ""; LAST = d; var cur = {}; d.rows.forEach(function (r) { cur[r.v] = r; });
      if (PREV) {
        d.rows.forEach(function (r) { delete MISS[r.v]; if (!PREV[r.v]) { notify("join", r); FEED.unshift({ k: "join", n: r.n, d: r.d, t: Date.now() }); } });
        Object.keys(PREV).forEach(function (v) { if (cur[v]) return; MISS[v] = (MISS[v] || 0) + 1; if (MISS[v] >= 2) { notify("leave", PREV[v]); FEED.unshift({ k: "leave", n: PREV[v].n, d: PREV[v].d, t: Date.now() }); delete MISS[v]; } else cur[v] = PREV[v]; });
        FEED = FEED.slice(0, 40);
      }
      PREV = cur; paint();
    }).catch(function (e) { ERR = e && e.message ? e.message : "error"; paint(); });
  }
  function paint() {
    var tb = document.querySelector('#tabs [data-t="usr"]'); if (tb && LAST) tb.textContent = "👤 User Info (🟢 " + bd(LAST.online) + ")";
    var b = document.getElementById("onbox"); if (!b) return;
    if (!LAST) { b.innerHTML = ERR ? '<p class="warn">অনলাইন তথ্য লোড হয়নি: ' + esc(ERR) + '</p><p class="sm">supabase-userinfo.sql একবার Supabase SQL Editor-এ চালান।</p>' : "⏳ অনলাইন তথ্য লোড হচ্ছে…"; return; }
    var rows = LAST.rows.map(function (r) { return '<button class="l s" type="button" data-uu="' + esc(r.v) + '"><span class="udot on"></span>' + esc(r.n) + (r.d ? " · " + esc(r.d) : "") + "</button>"; }).join("");
    b.innerHTML = "<h2>🟢 এখন অনলাইন: <b>" + bd(LAST.online) + "</b><small>আজ " + bd(LAST.today) + " জন · মোট " + bd(LAST.total) + ' জন ভিজিটর</small></h2><div class="act">' + (rows || '<span class="sm">এই মুহূর্তে কেউ অনলাইনে নেই।</span>') + '</div><div class="act" style="margin-top:8px"><button class="s" type="button" data-go="usr">👥 Visitor List / User Info</button></div>' +
      '<h3 style="margin:10px 0 0;font-size:15px">Join / Leave</h3><div class="onf">' + (FEED.map(function (f) { return "<div>" + (f.k === "join" ? "🟢 জয়েন" : "⚪ লিভ") + " · <b>" + esc(f.n) + "</b>" + (f.d ? " (" + esc(f.d) + ")" : "") + " · " + ago(f.t) + "</div>"; }).join("") || '<span class="sm">এই পেজ খোলা থাকা অবস্থায় কেউ ঢুকলে বা বের হলে এখানে ও ওপরের কোণে দেখাবে।</span>') + "</div>";
  }

  // ---------- ড্যাশবোর্ডে বক্স বসানো ----------
  var od = (window.MCA_VIEWS || {}).dash;
  if (od) window.MCA_VIEWS.dash = function () { return od.apply(this, arguments).then(function () { var V = document.getElementById("view"); if (V) { V.insertAdjacentHTML("afterbegin", '<div class="c onb" id="onbox" style="margin-bottom:10px"></div>'); paint(); poll(); } }); };

  // ---------- User Info ট্যাব (Visitor List) ----------
  window.MCA_TABS = (window.MCA_TABS || []).concat([["usr", "👤 User Info"]]);
  window.MCA_VIEWS = Object.assign(window.MCA_VIEWS || {}, { usr: users });
  // ইউজারের অবস্থা বাছা (✅ ❔ 🚫 📵): একই window.MCFL (admin-folders.js); না থাকলে তালিকা আগের মতোই। চাবি = "d:"+ডিভাইস (voter), না থাকলে "n:"+নাম (ছোট হাতের)।
  var FLU = {}, FLREG = 0;
  function flagsLoad(append) {
    if (!window.MCFL) return Promise.resolve();
    if (!FLREG) { FLREG = 1; window.MCFL.reg(function () { return FLU; }); }
    return append ? Promise.resolve() : M().rpc("mc2_flag_all").then(function (r) { FLU = r || {}; }).catch(function () {});
  }
  function flagBox(x) {
    if (!window.MCFL) return "";
    var k = x.voter ? "d:" + x.voter : (x.gname || x.nick) ? "n:" + String(x.gname || x.nick).trim().toLowerCase() : ""; if (!k) return "";
    return '<div class="act" style="margin-top:4px">' + window.MCFL.ctl(k, FLU[k] || "") + "</div>";
  }
  // ---------- আরও ফিল্টার (নতুন SQL: supabase-new-20261108.sql; না চালালে আগের মতোই চলে) ----------
  var NEWF = true;
  function fetchUsers(pg) {
    var off = (pg || 0) * 50;
    if (!NEWF) return M().rpc("mc2_admin_users", { p_q: ST.q, p_online: ST.on, p_limit: 50, p_offset: off });
    return M().rpc("mc2_admin_users2", { p_q: ST.q, p_status: ST.st === "1" ? "on" : ST.st === "2" ? "off" : "all", p_gender: ST.g, p_dept: ST.d, p_sess: ST.s, p_country: ST.c, p_dev: ST.dv, p_os: ST.os, p_br: ST.br, p_phone: ST.ph, p_score: ST.sc, p_active: ST.ac, p_sort: ST.so, p_from: ST.ac === "custom" ? ST.f : "", p_to: ST.ac === "custom" ? ST.t : "", p_limit: 50, p_offset: off })
      .catch(function () { NEWF = false; return M().rpc("mc2_admin_users", { p_q: ST.q, p_online: ST.on, p_limit: 50, p_offset: off }); });
  }
  function selx(id, label, cur, list) { return "<label>" + label + '<select id="' + id + '">' + list.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(cur) === String(o[0]) ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("") + "</select></label>"; }
  function lst(all, arr, cur, fn) { var a = (arr || []).slice(); if (cur && a.indexOf(cur) < 0) a.push(cur); return [["", all]].concat(a.map(function (v) { return [v, fn ? fn(v) : v]; })); }
  function filt2(d) {
    if (!d.depts) return '<p class="sm">আরও ফিল্টার চালু করতে supabase-new-20261108.sql একবার Supabase SQL Editor-এ চালান।</p>';
    var any = ST.g || ST.d || ST.s || ST.c || ST.dv || ST.os || ST.br || ST.ph || ST.sc || ST.ac || ST.so !== "new";
    return "<details id=\"unDet\"" + (any || ST.open === "1" ? " open" : "") + '><summary class="sm"><b>🔧 আরও ফিল্টার' + (any ? " (চালু আছে)" : "") + '</b></summary><div class="row">' +
      selx("unG", "জেন্ডার", ST.g, [["", "সব"], ["m", "👦 ছেলে"], ["f", "👧 মেয়ে"], ["x", "⚪ ভিজিটর/অজানা"]]) +
      selx("unD", "বিভাগ", ST.d, lst("সব বিভাগ", d.depts, ST.d)) + selx("unSs", "সেশন", ST.s, lst("সব সেশন", d.sessions, ST.s)) +
      selx("unC", "দেশ", ST.c, lst("সব দেশ", d.countries, ST.c, function (v) { var c = country(v); return c.flag + " " + c.name; })) +
      selx("unDv", "ডিভাইসের ধরন", ST.dv, [["", "সব ধরন"], ["mob", "📱 মোবাইল"], ["tab", "ট্যাবলেট"], ["pc", "💻 কম্পিউটার"]]) +
      selx("unOs", "অপারেটিং সিস্টেম", ST.os, [["", "সব"], ["and", "Android"], ["ios", "iPhone/iPad (iOS)"], ["win", "Windows"], ["mac", "Mac"], ["lin", "Linux"]]) +
      selx("unBr", "ব্রাউজার", ST.br, [["", "সব"], ["chr", "Chrome"], ["sam", "Samsung Internet"], ["fb", "Facebook অ্যাপের ব্রাউজার"], ["msg", "Messenger ব্রাউজার"], ["ig", "Instagram ব্রাউজার"], ["ff", "Firefox"], ["edg", "Edge"], ["opr", "Opera"], ["saf", "Safari"], ["oth", "অন্যান্য/অজানা"]]) +
      selx("unPh", "ফোন নম্বর", ST.ph, [["", "সব"], ["yes", "📞 নম্বর আছে"], ["no", "নম্বর নেই"]]) +
      selx("unSc", "স্কোর", ST.sc, [["", "সব"], ["yes", "খেলেছে (স্কোর আছে)"], ["no", "এখনো খেলেনি"]]) +
      selx("unAc", "শেষ সক্রিয়", ST.ac, [["", "যেকোনো সময়"], ["today", "আজ"], ["7", "গত ৭ দিন"], ["30", "গত ৩০ দিন"], ["old", "৩০ দিনের বেশি আগে"], ["custom", "📅 নিজের তারিখ"]]) +
      '<label id="unFl"' + (ST.ac === "custom" ? "" : ' hidden') + '>থেকে<input type="date" id="unFr" value="' + esc(ST.f) + '"></label><label id="unTl"' + (ST.ac === "custom" ? "" : ' hidden') + '>পর্যন্ত<input type="date" id="unTo" value="' + esc(ST.t) + '"></label>' +
      selx("unSo", "সাজানো", ST.so, [["new", "নতুন আগে (শেষ সক্রিয়)"], ["old", "পুরোনো আগে"], ["score", "বেশি স্কোর আগে"], ["visits", "বেশি ভিজিট আগে"]]) + "</div></details>";
  }
  // ---------- বাছাই করে ইউজার মোছা (নতুন SQL: supabase-new-20261109.sql) ----------
  var SEL = {}, ALLF = false, TOTAL = 0, PAGEV = [], PAGER = {}, CUNL = false;
  var WHAT = [["visitor", "👤 ভিজিটর রেকর্ড (এই তালিকা থেকে)"], ["scores", "🏆 স্কোর (লিডারবোর্ড)"], ["cards", "🪪 কার্ড + টপ হিস্টরি"], ["entries", "🎁 কনটেস্ট/লটারি এন্ট্রি"], ["answers", "📝 প্রশ্নের উত্তর"], ["chat", "💬 চ্যাট বার্তা ও রিঅ্যাকশন"], ["mod", "🚫 মডারেশন রেকর্ড (ওয়ার্নিং/ব্যান/রিপোর্ট)"]];
  var WN = { visitor: "ভিজিটর রেকর্ড", scores: "স্কোর", cards: "কার্ড", entries: "এন্ট্রি", answers: "উত্তর", chat: "চ্যাট বার্তা", mod: "মডারেশন রেকর্ড" };
  function selCount() { return ALLF ? TOTAL : Object.keys(SEL).length; }
  function delBar() {
    return '<div class="c" id="unDel" style="margin:8px 0;padding:10px"><div class="act" style="align-items:center;flex-wrap:wrap"><label style="display:inline-flex;gap:6px;align-items:center;font-weight:700"><input type="checkbox" id="unPgAll" style="width:18px;height:18px"> এই পেজের সবাই</label>' +
      '<label style="display:inline-flex;gap:6px;align-items:center;font-weight:700"><input type="checkbox" id="unAllF"' + (ALLF ? " checked" : "") + ' style="width:18px;height:18px"> ফিল্টার/খোঁজা অনুযায়ী সবাই (' + bd(TOTAL) + ' জন, সব পেজ)</label>' +
      '<b id="unSelN" class="sm"></b><button class="l" id="unSh" type="button" disabled>📄 বাছাইগুলোর কার্ড (এক পেজে)</button><button class="d" id="unDelB" type="button" disabled>🗑 বাছাইগুলো মুছুন…</button></div>' +
      '<div id="unDelP" hidden style="margin-top:8px"><p class="sm"><b>কোন কোন ডেটা মুছবেন? যেগুলোতে টিক দেবেন শুধু সেগুলোই যাবে।</b></p>' +
      WHAT.map(function (w) { var lk = w[0] === "cards"; return '<label style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="checkbox" class="unWh" value="' + w[0] + '"' + (lk ? " disabled" : "") + ' style="width:18px;height:18px"> ' + w[1] + (lk ? ' <span id="unCk" class="sm">🔒 লক করা</span> <button class="l s" id="unCu" type="button">🔓 আনলক</button>' : "") + "</label>"; }).join("") +
      '<div class="act" style="margin-top:6px"><button class="l s" id="unWhAll" type="button">সব ডেটায় টিক</button><button class="d" id="unGo" type="button">✔ মুছে ফেলুন</button><button class="l" id="unNo" type="button">বাতিল</button></div></div></div>';
  }
  function collectVoters() {
    if (!ALLF) return Promise.resolve(Object.keys(SEL));
    var out = [];
    var step = function (off) {
      return M().rpc("mc2_admin_users2", { p_q: ST.q, p_status: ST.st === "1" ? "on" : ST.st === "2" ? "off" : "all", p_gender: ST.g, p_dept: ST.d, p_sess: ST.s, p_country: ST.c, p_dev: ST.dv, p_os: ST.os, p_br: ST.br, p_phone: ST.ph, p_score: ST.sc, p_active: ST.ac, p_sort: ST.so, p_from: ST.ac === "custom" ? ST.f : "", p_to: ST.ac === "custom" ? ST.t : "", p_limit: 100, p_offset: off })
        .then(function (d) { (d.rows || []).forEach(function (r) { if (r.voter) out.push(r.voter); }); return (d.rows || []).length === 100 && out.length < 20000 ? step(off + 100) : out; });
    };
    return step(0);
  }
  function runDel(what, dry, vs, st) {
    st = st || { tot: {}, i: 0 }; // st.i = কতজনের মোছা শেষ (শুধু সফল ভাগ গোনা হয়)
    var next = function () {
      if (st.i >= vs.length) return Promise.resolve(st.tot);
      var ch = vs.slice(st.i, st.i + 200);
      return M().rpc("mc2_admin_users_del", { p_voters: ch, p_what: what, p_dry: !!dry, p_unlock_cards: CUNL }).then(function (r) { Object.keys(r || {}).forEach(function (k) { st.tot[k] = (st.tot[k] || 0) + (+r[k] || 0); }); st.i += ch.length; return next(); });
    };
    return next();
  }
  // আসল মোছা: মাঝপথে এরর এলে কতজন হলো/কতজন বাকি দেখায়, আর "আবার চেষ্টা" দিলে বাকিগুলো থেকে চলে
  function realDel(what, vs, st) {
    return runDel(what, false, vs, st).catch(function (e) {
      if (!st.i) throw e; // প্রথম ভাগেই এরর = কিছুই মোছেনি, আগের মতোই এরর দেখাবে
      var m = String((e && e.message) || e);
      if (window.confirm("⚠ মাঝপথে এরর হয়েছে: " + m + "\n\n" + bd(st.i) + " জনের মোছা শেষ, " + bd(vs.length - st.i) + " জন বাকি আছে।\n\nOK = বাকিগুলো আবার চেষ্টা করুন\nCancel = এখানেই থামুন")) return realDel(what, vs, st);
      var pe = new Error("__partial"); pe.st = st; pe.total = vs.length; throw pe;
    });
  }
  function delWire() {
    var upd = function () {
      var n = selCount(), e = document.getElementById("unSelN"), b = document.getElementById("unDelB");
      if (e) e.textContent = n ? "বাছা: " + bd(n) + " জন" : ""; if (b) b.disabled = !n; var sb0 = document.getElementById("unSh"); if (sb0) sb0.disabled = !n;
      var pa = document.getElementById("unPgAll"); if (pa) pa.checked = PAGEV.length > 0 && PAGEV.every(function (v) { return ALLF || SEL[v]; });
    };
    var L = document.getElementById("unL"); if (!L) return;
    L.addEventListener("change", function (e) { var c = e.target.closest("[data-ck]"); if (!c) return; if (ALLF) { ALLF = false; PAGEV.forEach(function (v) { SEL[v] = true; }); document.getElementById("unAllF").checked = false; } if (c.checked) SEL[c.dataset.ck] = true; else delete SEL[c.dataset.ck]; upd(); });
    document.getElementById("unPgAll").onchange = function () { var on = this.checked; if (ALLF) { ALLF = false; document.getElementById("unAllF").checked = false; } PAGEV.forEach(function (v) { if (on) SEL[v] = true; else delete SEL[v]; }); L.querySelectorAll("[data-ck]").forEach(function (c) { c.checked = on; }); upd(); };
    document.getElementById("unAllF").onchange = function () { ALLF = this.checked; if (ALLF) SEL = {}; L.querySelectorAll("[data-ck]").forEach(function (c) { c.checked = ALLF; }); upd(); };
    document.getElementById("unDelB").onclick = function () { document.getElementById("unDelP").hidden = false; };
    var shb = document.getElementById("unSh"); if (shb) shb.onclick = function () { // 📄 এই পেজের বাছা ইউজারদের কার্ড এক পেজে / একা
      if (!window.MCSheet) { alert("শিট সিস্টেম (admin-sheet.js) লোড হয়নি — পেজ রিফ্রেশ করুন।"); return; }
      var vs = ALLF ? PAGEV.slice() : Object.keys(SEL), ps = [], miss = 0;
      vs.forEach(function (v) { var r = PAGER[v]; if (!r) { miss++; return; } ps.push({ key: "u:" + v, name: nm(r), device: v, dept: r.dept || "", batch: r.batch || "", score: r.score != null ? r.score : null, rank: null }); });
      if (!ps.length) { alert("বাছা ইউজারদের তথ্য এই পেজে নেই — এই পেজ থেকেই টিক দিন।"); return; }
      if (miss) alert(bd(miss) + " জন অন্য পেজের, তাই বাদ গেল। এই পেজের " + bd(ps.length) + " জন নিয়ে খুলছি।");
      window.MCSheet.open(ps, { kind: "card", pre: "all", title: "বাছা ইউজার" });
    };
    document.getElementById("unNo").onclick = function () { document.getElementById("unDelP").hidden = true; };
    document.getElementById("unWhAll").onclick = function () { document.querySelectorAll(".unWh").forEach(function (c) { if (!c.disabled) c.checked = true; }); };
    document.getElementById("unCu").onclick = function () {
      var c = document.querySelector('.unWh[value="cards"]');
      if (CUNL) { CUNL = false; c.checked = false; c.disabled = true; this.textContent = "🔓 আনলক"; document.getElementById("unCk").textContent = "🔒 লক করা"; return; }
      if (window.prompt("কার্ড মোছা লক করা আছে। আনলক করতে বড় হাতের CARD লিখুন:") !== "CARD") return;
      CUNL = true; c.disabled = false; this.textContent = "🔒 আবার লক করুন"; document.getElementById("unCk").textContent = "🔓 আনলক আছে";
    };
    document.getElementById("unGo").onclick = function () {
      var what = Array.prototype.map.call(document.querySelectorAll(".unWh:checked"), function (c) { return c.value; }).filter(function (k) { return k !== "cards" || CUNL; });
      if (!what.length) return alert("কোন ডেটা মুছবেন তা অন্তত একটায় টিক দিন।");
      var btn = this; btn.disabled = true; var vs;
      collectVoters().then(function (v) { vs = v; if (!vs.length) throw new Error("কাউকে বাছা হয়নি।"); return runDel(what, true, vs); }).then(function (c) {
        var lines = Object.keys(c).filter(function (k) { return WN[k] && (c[k] || what.indexOf(k) >= 0); }).map(function (k) { return "• " + WN[k] + ": " + bd(c[k] || 0) + "টি" + (what.indexOf(k) < 0 ? " (কার্ডের সাথে যাবে)" : ""); }).join("\n");
        if (!window.confirm(bd(vs.length) + " জন ইউজারের এই ডেটা চিরতরে মুছে যাবে (ফেরত আনা যাবে না):\n\n" + lines + "\n\nমুছবেন?")) throw new Error("__cancel");
        if (what.indexOf("cards") >= 0 && window.prompt("⚠ " + bd(vs.length) + " জনের কার্ড মুছতে যাচ্ছেন। নিশ্চিত করতে DELETE CARD লিখুন:") !== "DELETE CARD") throw new Error("__cancel");
        if (vs.length > 20 && window.prompt("নিশ্চিত করতে সংখ্যাটি লিখুন: " + vs.length) !== String(vs.length)) throw new Error("__cancel");
        return realDel(what, vs, { tot: {}, i: 0 });
      }).then(function (c) {
        SEL = {}; ALLF = false; CUNL = false;
        alert("মোছা হয়েছে:\n" + Object.keys(c).filter(function (k) { return WN[k] && (c[k] || what.indexOf(k) >= 0); }).map(function (k) { return WN[k] + ": " + bd(c[k] || 0); }).join("\n"));
        return users();
      }).catch(function (e) {
        btn.disabled = false;
        if (e && e.message === "__cancel") return;
        if (e && e.message === "__partial") {
          var ps = e.st; SEL = {}; ALLF = false; CUNL = false;
          alert("⚠ আংশিক মোছা হয়েছে: " + bd(ps.i) + " জনের মোছা শেষ, " + bd(e.total - ps.i) + " জন বাকি (এগুলো মোছা হয়নি)।\n\nযা মোছা হয়েছে:\n" + Object.keys(ps.tot).filter(function (k) { return WN[k]; }).map(function (k) { return WN[k] + ": " + bd(ps.tot[k] || 0); }).join("\n") + "\n\nবাকিদের আবার বাছাই করে মুছুন।");
          return users();
        }
        var m = String((e && e.message) || e);
        alert(/mc2_admin_users_del|function|schema/i.test(m) ? "মোছার ফাংশন নেই। supabase-new-20261109.sql একবার Supabase SQL Editor-এ চালান।\n\n" + m : m);
      });
    };
    upd();
  }
  function users(pg) {
    saveST();
    return flagsLoad(!!pg).then(function () { return fetchUsers(pg); }).then(function (d) {
      var V = M().$("#view"), item = function (x) {
        return '<div class="it"><div><input type="checkbox" class="unCk" data-ck="' + esc(x.voter) + '"' + (SEL[x.voter] || ALLF ? " checked" : "") + ' style="width:18px;height:18px;margin:0 6px 0 0;vertical-align:middle"><span class="udot' + (x.online ? " on" : "") + '"></span><button class="lk" type="button" data-uu="' + esc(x.voter) + '">' + esc(nm(x)) + '</button>' + gtag(x.voter, nm(x), x.gender) + ' <span class="tag">' + esc(x.gdept || x.cdept || "—") + '</span><span class="tag">' + esc(x.gbatch || x.csess || "—") + '</span>' + (x.best != null ? '<span class="tag">স্কোর ' + bd(x.best) + "</span>" : "") + '</div><div class="sm">' + esc(x.uid) + " · " + (x.online ? "🟢 অনলাইন" : "Last Active: " + ago(x.ls)) + " · আইপি " + esc(x.ip || "—") + " · " + esc(loc(x)) + " · " + esc(ua(x.ua, x.info)) + (x.phone ? " · 📞 " + esc(x.phone) : "") + (x.info && x.info.sw ? " · " + esc(x.info.sw) : "") + "</div>" + flagBox(x) + "</div>";
      };
      ST.pg = pg || 0; TOTAL = d.total || 0; PAGEV = d.rows.map(function (r) { return r.voter; }); PAGER = {}; d.rows.forEach(function (r) { PAGER[r.voter] = r; });
      V.innerHTML = "<h2>👤 User Info — Visitor List (" + bd(d.total) + ')</h2><div id="unSumBox"></div><div class="row"><label>খুঁজুন (নাম, বিভাগ, সেশন, আইপি, জেলা/শহর, আইডি)<input id="unQ" value="' + esc(ST.q) + '"></label><label>দেখান<select id="unF"><option value="0"' + (ST.st === "0" ? " selected" : "") + '>সব ভিজিটর</option><option value="1"' + (ST.st === "1" ? " selected" : "") + '>শুধু অনলাইন</option>' + (d.depts ? '<option value="2"' + (ST.st === "2" ? " selected" : "") + '>শুধু অফলাইন</option>' : "") + '</select></label><button id="unS" type="button">🔎 খুঁজুন</button><button class="l" id="unR" type="button">✖ ফিল্টার মুছুন</button></div>' + filt2(d) + '<div id="unDelBox"></div><div id="unAcBox"></div><p class="sm">নামে ক্লিক করলে পুরো তথ্য খুলবে। এই তালিকা সাইটে Supabase চালু করার পর যারা ঢুকেছে তাদের নিয়ে।</p><div id="unL">' + (d.rows.map(item).join("") || '<p class="sm">কোনো ভিজিটর পাওয়া যায়নি।</p>') + '</div><div id="unPg">' + (window.MCPG ? window.MCPG.html(ST.pg, d.total, 50, "data-up") : "") + "</div>";
      document.getElementById("unDelBox").innerHTML = delBar(); delWire(); acWire();
      var dt = document.getElementById("unDet"); if (dt) dt.addEventListener("toggle", function () { ST.open = dt.open ? "1" : "0"; saveST(); });
      if (!document.getElementById("unFloat")) { var fb = document.createElement("button"); fb.id = "unFloat"; fb.type = "button"; fb.textContent = "🔎 খোঁজো";
        fb.style.cssText = "position:fixed;right:14px;bottom:18px;z-index:50;border:0;border-radius:24px;padding:12px 16px;background:#1a56db;color:#fff;font-size:15px;box-shadow:0 4px 12px #0004;cursor:pointer";
        fb.onclick = function () { var d = document.getElementById("unDet"); if (d) d.open = true; var q = document.getElementById("unQ"); if (q) { q.scrollIntoView({ behavior: "smooth", block: "center" }); q.focus(); } };
        document.body.appendChild(fb); }
      var gv = function (id, k) { var e = document.getElementById(id); if (e) ST[k] = e.value; };
      var go = function () { ST.q = document.getElementById("unQ").value.trim(); var f = document.getElementById("unF").value; ST.st = f; ST.on = f === "1"; gv("unG", "g"); gv("unD", "d"); gv("unSs", "s"); gv("unC", "c"); gv("unDv", "dv"); gv("unOs", "os"); gv("unBr", "br"); gv("unPh", "ph"); gv("unSc", "sc"); gv("unAc", "ac"); gv("unFr", "f"); gv("unTo", "t"); gv("unSo", "so"); SEL = {}; ALLF = false; users().catch(M().fail); };
      var ac = document.getElementById("unAc"); if (ac) ac.onchange = function () { var c = ac.value === "custom"; document.getElementById("unFl").hidden = !c; document.getElementById("unTl").hidden = !c; };
      document.getElementById("unR").onclick = function () { ST.q = ""; ST.on = false; ST.st = "0"; ST.g = ST.d = ST.s = ST.c = ST.dv = ST.os = ST.br = ST.ph = ST.sc = ST.ac = ""; ST.f = ST.t = ""; ST.so = "new"; SEL = {}; ALLF = false; users().catch(M().fail); };
      document.getElementById("unS").onclick = go; document.getElementById("unQ").onkeydown = function (e) { if (e.key === "Enter") go(); }; 
      document.getElementById("unPg").onclick = function (e) { var b = e.target.closest("[data-up]"); if (b && !b.disabled) users(+b.dataset.up).catch(M().fail); };
    });
  }

  // ---------- নাম ক্লিক: পুরো User Info ----------
  function show(voter) {
    M().rpc("mc2_admin_user", { p_voter: voter }).then(function (u) {
      u = u || { voter: voter }; // তথ্য না থাকলে খালি (—) দেখায়, এরর নয়
      var i = u.info || {}, nmx = u.gname || u.nick || "অজানা", sum, row = function (k, v) { return "<dt>" + k + "</dt><dd>" + (v == null || v === "" ? "—" : v) + "</dd>"; };
      var dev = [i.sw && "স্ক্রিন " + i.sw, i.lang, i.tz, i.net && "নেট " + i.net, i.cores && i.cores + " কোর", i.mem && i.mem + " GB RAM", i.inapp ? "অ্যাপের ব্রাউজার" : ""].filter(Boolean).join(" · ");
      var phone = u.phone ? esc(u.phone) : "—", he = i.he || {};
      var more = [he.pl && (he.pl + (he.plv ? " " + he.plv : "")), he.arch && (he.arch + (he.bit ? "/" + he.bit + " বিট" : "")), he.br, i.cd && "রঙ " + i.cd + " বিট", i.ori, i.dpr && "DPR " + i.dpr, i.dl && "ডাউনলোড ~" + i.dl + " Mbps", i.rtt && "RTT " + i.rtt + "ms", i.sd ? "ডেটা-সেভার" : "", i.pwa ? "অ্যাপ হিসেবে ইনস্টল" : "", i.dark ? "ডার্ক মোড" : "", i.tzo != null && "UTC" + (i.tzo <= 0 ? "+" : "-") + Math.abs(i.tzo / 60), i.ref && "এসেছে: " + i.ref, i.q && "লিংক: " + i.q].filter(Boolean).join(" · ") || "—";
      sum = ["User ID: " + u.uid, "নাম: " + nmx + (u.nick && u.nick !== nmx ? " (চ্যাট: " + u.nick + ")" : ""), "বিভাগ: " + (u.gdept || "—") + " | চ্যাট বিভাগ: " + (u.cdept || "—"), "সেশন: " + (u.gbatch || "—") + " | চ্যাট সেশন: " + (u.csess || "—"), "সর্বোচ্চ স্কোর: " + (u.best != null ? u.best : "—"), "IP: " + (u.ip || "—"), "লোকেশন: " + loc(u), "জেন্ডার: " + window.MCG.label(u.gender), "ফোন নম্বর: " + (u.phone || "—"), "ফোন মডেল: " + phoneModel(u.ua, i), "ডিভাইস: " + ua(u.ua, i), "স্ট্যাটাস: " + (u.online ? "অনলাইন" : "অফলাইন") + " | Last Active: " + (u.last ? new Date(u.last).toLocaleString("bn-BD") : "—"), "ফোন: " + (u.phone || "—"), "ডিভাইস আইডি: " + u.voter].join("\n");
      var o = document.createElement("div"); o.className = "unmo";
      o.innerHTML = '<div class="unb"><h2 style="margin:0">' + '<span class="udot' + (u.online ? " on" : "") + '"></span>' + esc(nmx) + ' <span class="tag">' + esc(u.uid) + "</span></h2><dl>" +
        row("স্ট্যাটাস", u.online ? "🟢 অনলাইন" + (u.joined ? " (" + dur(u.joined) + " ধরে)" : "") : "⚪ অফলাইন") + row("Last Active", u.last ? esc(new Date(u.last).toLocaleString("bn-BD")) + " · " + ago(new Date(u.last).getTime()) : "রেকর্ড নেই (এখনো উপস্থিতি লগ হয়নি)") +
        row("বর্তমান পেজ", esc(u.page)) + row("প্রথম দেখা / ভিজিট", (u.first ? esc(new Date(u.first).toLocaleString("bn-BD")) : "—") + (u.visits ? " · " + bd(u.visits) + " বার" : "")) +
        row("বিভাগ", esc(u.gdept) + (u.cdept ? ' <span class="sm">· চ্যাট: ' + esc(u.cdept) + "</span>" : "")) + row("সেশন", esc(u.gbatch) + (u.csess ? ' <span class="sm">· চ্যাট: ' + esc(u.csess) + "</span>" : "")) + row("জেন্ডার", esc(window.MCG.label(u.gender))) + (window.MCFB ? row("📣 ফেসবুকে ছাড়ার অনুমতি", '<span class="fbc" data-fbd="' + esc(voter) + '"></span>') : "") + row("চ্যাট নাম", esc(u.nick)) +
        row("স্কোর", u.best != null ? "<b>" + bd(u.best) + "</b> / ১০০০ (সেরা, " + bd(u.bestpct) + " শতাংশ) · " + bd(u.plays) + " বার খেলেছে" : "এখনো খেলেনি") +
        row("IP", esc(u.ip)) + row("আনুমানিক IP লোকেশন", esc(loc(u)) + (u.ip ? ' <a href="https://ipinfo.io/' + encodeURIComponent(u.ip) + '" target="_blank" rel="noopener noreferrer">বাইরের সাইটে দেখুন</a>' : "")) +
        row("ফোন মডেল", esc(phoneModel(u.ua, i))) + row("Browser / Device", esc(ua(u.ua, i))) + row("স্ক্রিন ও নেটওয়ার্ক", esc(dev)) + row("বাড়তি ব্রাউজার তথ্য", esc(more)) + row("ফোন নম্বর", phone) + row("চ্যাট বার্তা", bd(u.msgs || 0) + "টি") + "</dl>" +
        (u.scores && u.scores.length ? "<h3>সাম্প্রতিক স্কোর</h3><div class=\"sm\">" + u.scores.map(function (s) { return esc(s.name) + " · " + bd(s.score) + " · " + esc(s.dept) + " · " + esc(new Date(s.created_at).toLocaleDateString("bn-BD")); }).join("<br>") + "</div>" : "") +
        (u.lastmsgs && u.lastmsgs.length ? "<h3>শেষ বার্তা</h3><div class=\"sm\">" + u.lastmsgs.map(function (m) { return esc(m.sess || "") + ": " + esc(m.body); }).join("<br>") + "</div>" : "") +
        '<details><summary class="sm">User-Agent ও ডিভাইস আইডি</summary><div class="sm" style="overflow-wrap:anywhere">' + esc(u.ua) + "<br>" + esc(u.voter) + '</div></details><div class="act"><button class="l" type="button" data-cuu="' + esc(voter) + '" data-cname="' + esc(nmx) + '">🪪 কার্ড দেখুন</button><button id="unCp" type="button">📋 তথ্য কপি</button><button class="l" id="unX" type="button">বন্ধ করুন</button></div></div>';
      document.body.appendChild(o);
      o.onclick = function (e) { if (e.target === o || e.target.id === "unX") o.remove(); };
      o.querySelector("#unCp").onclick = function () { try { navigator.clipboard.writeText(sum); this.textContent = "✅ কপি হয়েছে"; } catch (er) { prompt("কপি করুন:", sum); } };
    }).catch(function (e) { M().fail(e); });
  }
  document.addEventListener("click", function (e) {
    var u = e.target.closest("[data-uu]"); if (u) { e.preventDefault(); return show(u.dataset.uu); }
    var g = e.target.closest("[data-go]"); if (g) { var b = document.querySelector('#tabs [data-t="' + g.dataset.go + '"]'); if (b) b.click(); }
  });
  tick = setInterval(poll, 8000); setTimeout(poll, 1500);
  window.MCA_USER = show;
  // অন্য অ্যাডমিন ফাইলের জন্য সহায়ক (ভিজিটর ট্যাব, মডারেশনের সক্রিয় ইউজার): ফোন মডেল, ব্রাউজার, দেশ (পতাকা + বাংলা নাম), কতক্ষণ আগে
  var RN = null; try { RN = new Intl.DisplayNames(["bn"], { type: "region" }); } catch (e) {}
  function country(c) {
    c = String(c || "").toUpperCase(); if (!/^[A-Z]{2}$/.test(c) || c === "XX" || c === "T1") return { code: "", flag: "🌐", name: c === "T1" ? "Tor/অজানা" : "দেশ অজানা" };
    var nm = c; try { nm = (RN && RN.of(c)) || c; } catch (e) {}
    return { code: c, flag: String.fromCodePoint(127397 + c.charCodeAt(0), 127397 + c.charCodeAt(1)), name: nm };
  }
  // জেন্ডার চিহ্ন (👦/👧/⚪): সব ট্যাবের জন্য একটাই জায়গা। ডিভাইস আইডি থাকলে ডিভাইস দিয়ে, না থাকলে নাম দিয়ে (নাম মেলানো আনুমানিক: একই নামে দুজন থাকলে ভুল হতে পারে)।
  var GM = null, GT = 0, GW = false;
  function gload() { if (GW) return; GW = true; M().rpc("mc2_admin_genders").then(function (r) { if (r && r.d) { GM = r; GT = Date.now(); } GW = false; }).catch(function () { GW = false; }); }
  setInterval(function () { if (!GM || Date.now() - GT > 300000) gload(); }, 4000); setTimeout(gload, 2000);

  // ---------- 📊 সামারি + 🧹 অটো-ক্লিন: ইউজার ইনফো (ইউজার তালিকা) ও ইউজার লগ (ভিজিট-লগ) — আলাদা অন/অফ ও আলাদা সংখ্যা (SQL: supabase-new-20261226.sql) ----------
  var AC = null, SM = null, ACE = "", ACM = { p: "", v: "" }, ACBAD = { p: false, v: false }, ACO = false, ACL = false;
  var PT = {
    p: { t: "👤 ইউজার ইনফো (ইউজার তালিকা)", rpc: "mc2_presence_clean_set", part: "presence", f: [["max", "সর্বোচ্চ কত জন থাকবে (বাড়তি পুরোনোরা কাটবে)", 1000000], ["ip", "একই আইপি-র সর্বোচ্চ কত সারি (বেশি হলে কাটবে)", 1000000], ["keep", "শেষ আসার কত ঘণ্টা পর্যন্ত কাটবে না", 720], ["days", "কত দিন না এলে কাটবে (দিন)", 3650]], note: "কার্ড আছে এমন ইউজার আর এখন অনলাইনে থাকা ইউজার কখনো কাটা হয় না।" },
    v: { t: "📜 ইউজার লগ (ভিজিট-লগ)", rpc: "mc2_visits_clean_set", part: "visits", f: [["max", "সর্বোচ্চ কত সারি থাকবে (পুরোনো কাটবে)", 1000000], ["ip", "একই আইপি-র সর্বোচ্চ কত সারি (বেশি হলে কাটবে)", 1000000], ["keep", "কত ঘণ্টার ভেতরের সারি কাটবে না", 720], ["days", "কত দিনের পুরোনো হলে কাটবে (দিন)", 3650]], note: "এই লগে প্রতি ভিজিটে নতুন সারি জমে।" }
  };
  function acErr(e) { var m = String((e && e.message) || e || ""); return /function|does not exist|schema cache|not found|404|PGRST/i.test(m) ? "⏳ নতুন SQL (supabase-new-20261226.sql) এখনো চালানো হয়নি — Supabase > SQL Editor-এ চালালে এই সামারি ও অটো-ক্লিন বক্স কাজ করবে। সাইট আগের মতোই চলছে।" : "❌ " + m; }
  function acSay(k, t, bad) { ACM[k] = t; ACBAD[k] = !!bad; var m = document.getElementById("unAcM" + k); if (m) { m.textContent = t; m.className = "sm" + (bad ? " warn" : ""); } }
  function tile(l, v) { return '<div style="border:1px solid #e0e6dc;border-radius:8px;padding:6px 8px"><div class="sm" style="opacity:.8">' + l + "</div><b>" + v + "</b></div>"; }
  function dtx(x) { if (!x) return "—"; var d = new Date(x); return isNaN(d) ? "—" : ago(d.getTime()); }
  // ---------- 💾 স্টোরেজ বার: ইউজার ইনফো / ইউজার লগ / বাকি ডাটাবেস / খালি জায়গা (শতাংশ সহ) ----------
  function memSkel() { return '<div class="memBar" aria-label="লোড হচ্ছে"><div class="memPulse"></div></div>'; }
  function memBar() {
    var lim = Number(SM.db_lim) > 0 ? Number(SM.db_lim) : 500;
    var p = Number(SM.p_mb) || 0, v = Number(SM.v_mb) || 0, db = Number(SM.db_mb) || 0;
    var oth = Math.max(0, db - p - v);
    function pc(x) { return Math.min(100, Math.round(x / lim * 1000) / 10); }
    var used = pc(db), free = Math.max(0, Math.round((100 - used) * 10) / 10);
    var segs = [["👤 ইউজার ইনফো", p, "#2563eb"], ["📜 ইউজার লগ", v, "#f59e0b"], ["🗃 বাকি ডাটাবেস", oth, "#94a3b8"]];
    var bar = '<div class="memBar" role="img" aria-label="ডাটাবেস ' + used + '% ভরা">' +
      segs.map(function (s) { return '<span title="' + s[0] + '" style="width:' + pc(s[1]) + '%;background:' + s[2] + '"></span>'; }).join("") +
      '</div>';
    var leg = segs.map(function (s) {
      return '<div class="memRow"><span class="memDot" style="background:' + s[2] + '"></span><span>' + s[0] + '</span><b>' + bd(s[1]) + ' MB</b><span class="sm">' + bd(pc(s[1])) + '% (সীমার)</span></div>';
    }).join("");
    return '<div class="memWrap"><div class="memHead"><b>💾 ডাটাবেস স্টোরেজ</b><span class="sm">মোট ' + bd(db) + ' MB / সীমা ' + bd(lim) + ' MB</span></div>' +
      bar +
      '<div class="memLegend">' + leg + '<div class="memRow"><span class="memDot" style="background:#e5e7eb;border:1px solid #9ca3af"></span><span>খালি জায়গা</span><b>' + bd(free) + '% পড়ে আছে</b><span class="sm">ভরা ' + bd(used) + '%</span></div></div>' +
      '<p class="sm" style="margin:4px 0 0">সার্ভারের হিসাব; কার্ড ট্যাবের আলাদা হিসাব আছে।</p></div>';
  }
  function sumHtml() {
    var h = '<div style="border:1px solid #cfd8c8;border-radius:10px;padding:10px;margin:8px 0"><b>📊 ফুল সামারি</b> <button class="s" id="unSumR" type="button">🔄 রিফ্রেশ</button>';
    if (ACE) return h + '<p class="sm warn">' + esc(ACE) + "</p></div>";
    if (!SM) return h + memSkel() + '<p class="sm">⏳ জায়গার হিসাব লোড হচ্ছে…</p></div>';
    h += memBar();
    var g = 'style="display:grid;gap:6px;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));margin:6px 0"';
    h += '<p class="sm" style="margin:6px 0 2px"><b>👤 ইউজার ইনফো (ইউজার তালিকা)</b> — ডাটাবেসে জায়গা: <b>' + bd(SM.p_mb) + " MB</b></p><div " + g + ">" +
      tile("মোট ইউজার", bd(SM.p_total)) + tile("🟢 এখন অনলাইন", bd(SM.p_online)) + tile("গত ১ ঘণ্টায় এসেছে", bd(SM.p_h1)) + tile("গত ২৪ ঘণ্টায় এসেছে", bd(SM.p_h24)) + tile("🪪 কার্ডওয়ালা (সুরক্ষিত)", bd(SM.p_cards)) + tile("কার্ডছাড়া", bd(Math.max(0, SM.p_total - SM.p_cards))) +
      tile("আলাদা আইপি", bd(SM.p_ips)) + tile("আইপি নেই", bd(SM.p_noip)) + tile("সীমার বেশি আইপি", bd(SM.p_bigip)) + tile("সবচেয়ে পুরোনো", esc(dtx(SM.p_old))) + "</div>" +
      '<p class="sm" style="margin:6px 0 2px"><b>📜 ইউজার লগ (ভিজিট-লগ)</b> — ডাটাবেসে জায়গা: <b>' + bd(SM.v_mb) + " MB</b></p><div " + g + ">" +
      tile("মোট সারি", bd(SM.v_total)) + tile("গত ২৪ ঘণ্টায় নতুন", bd(SM.v_h24)) + tile("আলাদা আইপি", bd(SM.v_ips)) + tile("আলাদা ডিভাইস", bd(SM.v_devs)) + tile("সীমার বেশি আইপি", bd(SM.v_bigip)) + tile("বাড়তি সারি (সীমার ওপরে)", bd(SM.v_over)) + tile("সবচেয়ে পুরোনো", esc(dtx(SM.v_old))) + "</div>" +
      '<p class="sm" style="margin:6px 0">পুরো ডাটাবেস এখন: <b>' + bd(SM.db_mb) + " MB</b></p>";
    if (SM.top && SM.top.length) h += '<p class="sm" style="margin:6px 0 2px"><b>🌐 সবচেয়ে বেশি সারির আইপি</b></p><div style="overflow-x:auto"><table class="sm" style="border-collapse:collapse;min-width:260px"><tr><th style="text-align:left;padding:2px 8px">আইপি</th><th style="padding:2px 8px">ইউজার সারি</th><th style="padding:2px 8px">ভিজিট সারি</th></tr>' + SM.top.map(function (r) { return '<tr><td style="padding:2px 8px">' + esc(r.ip) + '</td><td style="padding:2px 8px;text-align:center">' + bd(r.p) + '</td><td style="padding:2px 8px;text-align:center">' + bd(r.v) + "</td></tr>"; }).join("") + "</table></div>";
    return h + "</div>";
  }
  function numF(k, f, val) { return "<label>" + f[1] + '<input type="number" id="unAc' + k + f[0] + '" min="0" max="' + f[2] + '" step="1" value="' + esc(val) + '"></label>'; }
  function blk(k) {
    var P = PT[k], c = AC[k];
    return '<div style="border:1px solid #e0e6dc;border-radius:8px;padding:8px;margin:8px 0"><b>' + P.t + "</b> — " + (c.auto ? "🟢 চালু" : "⚪ বন্ধ") + '<p class="sm">' + P.note + " ০ = ওই নিয়ম বন্ধ। নিচের \"ঘণ্টা\" ঘরের ভেতরের সারি কাটা হয় না। প্রতি ১০ মিনিটে প্রতি নিয়মে সর্বোচ্চ ২০০০ সারি।</p>" +
      '<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="unAc' + k + 'On"' + (c.auto ? " checked" : "") + "> এটার অটো-ক্লিন চালু (আলাদা সুইচ)</label>" +
      '<div class="row">' + P.f.map(function (f) { return numF(k, f, c[f[0]]); }).join("") + "</div>" +
      '<p class="sm">সেভ করা সেটিংয়ে এখনই যেত: দিন-নিয়মে <b>' + bd(c.n_days || 0) + "</b> + একই আইপি <b>" + bd(c.n_ip || 0) + "</b> + সংখ্যা-নিয়মে <b>" + bd(c.n_count || 0) + "</b> সারি।</p>" +
      '<div class="act"><button class="l" data-ac="s" data-k="' + k + '" type="button">💾 সেভ</button><button class="s" data-ac="p" data-k="' + k + '" type="button">🔍 পরীক্ষা (কিছু মুছবে না)</button><button class="d s" data-ac="r" data-k="' + k + '" type="button">🧹 এখনই চালান</button></div>' +
      '<p id="unAcM' + k + '" class="sm' + (ACBAD[k] ? " warn" : "") + '">' + esc(ACM[k]) + "</p></div>";
  }
  function acHtml() {
    var h = '<details id="unAc" style="margin:8px 0;border:1px solid #cfd8c8;border-radius:10px;padding:8px 10px"' + (ACO ? " open" : "") + "><summary><b>🧹 অটো-ক্লিন সেটিং (ইউজার ইনফো ও ইউজার লগ — আলাদা আলাদা)</b></summary>";
    if (ACE) return h + '<p class="sm warn">' + esc(ACE) + "</p></details>";
    if (!AC) return h + '<p class="sm">⏳ লোড হচ্ছে…</p></details>';
    return h + blk("p") + blk("v") + "</details>";
  }
  function acPaint() {
    var s = document.getElementById("unSumBox"), b = document.getElementById("unAcBox");
    if (s) s.innerHTML = sumHtml();
    if (b) { b.innerHTML = acHtml(); var d = document.getElementById("unAc"); if (d) d.addEventListener("toggle", function () { ACO = d.open; }); }
  }
  function acLoad() { return Promise.all([M().rpc("mc2_presence_clean_get"), M().rpc("mc2_presence_summary")]).then(function (r) { AC = r[0]; SM = r[1]; ACE = ""; }).catch(function (e) { AC = null; SM = null; ACE = acErr(e); }); }
  function acRead(k) {
    var P = PT[k], o = { p_auto: document.getElementById("unAc" + k + "On").checked };
    var m = { max: "p_max", ip: "p_ip_max", keep: "p_keep_hr", days: "p_days" };
    for (var i = 0; i < P.f.length; i++) { var f = P.f[i], n = Math.round(+document.getElementById("unAc" + k + f[0]).value); if (!(n >= 0 && n <= f[2])) { acSay(k, "❌ " + f[1] + ": ০ থেকে " + bd(f[2]) + "-এর মধ্যে পূর্ণ সংখ্যা দিন।", true); return null; } o[m[f[0]]] = n; }
    return o;
  }
  function acSum(r) { r = r || {}; return "দিন-নিয়মে " + bd(r.days || 0) + " + একই আইপি " + bd(r.ip || 0) + " + সংখ্যা-নিয়মে " + bd(r.count || 0) + " সারি"; }
  function acWire() {
    acPaint(); var b = document.getElementById("unAcBox"), s = document.getElementById("unSumBox"); if (!b) return;
    if (!AC && !ACE && !ACL) { ACL = true; acLoad().then(function () { ACL = false; acPaint(); }); }
    if (s) s.onclick = function (e) { if (e.target.id === "unSumR") { SM = null; acPaint(); acLoad().then(acPaint); } };
    b.onclick = function (e) {
      var t = e.target.closest("button[data-ac]"); if (!t) return; var a = t.dataset.ac, k = t.dataset.k, P = PT[k];
      if (a === "s") { var v = acRead(k); if (!v) return; M().rpc(P.rpc, v).then(function () { return acLoad(); }).then(function () { acPaint(); acSay(k, "✅ সেভ হয়েছে।"); }).catch(function (x) { acSay(k, acErr(x), true); }); return; }
      if (a === "p") { M().rpc("mc2_presence_clean_run", { p_dry: true, p_part: P.part }).then(function (r) { acSay(k, "🔍 পরীক্ষা (সেভ করা সেটিং ধরে; কিছু মোছা হয়নি) — কাটত: " + acSum(r[k]) + "।"); }).catch(function (x) { acSay(k, acErr(x), true); }); return; }
      if (a === "r") { if (!confirm("এখনই সেভ করা সেটিংয়ে " + P.t + " থেকে পুরোনো সারি কাটবেন? (কাটা ডেটা ফেরত আসবে না)")) return; M().rpc("mc2_presence_clean_run", { p_dry: false, p_part: P.part }).then(function (r) { return acLoad().then(function () { acPaint(); acSay(k, "✅ চালানো হয়েছে — কেটেছে: " + acSum(r[k]) + "।"); }); }).catch(function (x) { acSay(k, acErr(x), true); }); }
    };
  }
  var GL = { m: ["👦", "ছেলে"], f: ["👧", "মেয়ে"], x: ["⚪", "ভিজিটর/অজানা"] };
  function gtag(dev, name, g) {
    if (!g && GM) g = (dev && GM.d[dev]) || GM.n[String(name || "").trim().toLowerCase()];
    var o = GL[g]; return (o ? ' <span class="gdr" title="' + o[1] + '">' + o[0] + "</span>" : "") + (window.MCFB ? window.MCFB.span(dev) : ""); // + ফেসবুক-অনুমতির চিহ্ন (admin-fbc.js)
  }
  window.MCG = { tag: gtag, label: function (g) { return GL[g] ? GL[g][0] + " " + GL[g][1] : "—"; }, reload: gload };
  window.MCA_FMT = { ua: ua, phone: phoneModel, loc: loc, ago: ago, dur: dur, bd: bd, country: country };
})();
